package com.bitc.board.controller;

import com.bitc.board.dto.DfDto;
import com.bitc.board.service.DfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageInfo;

import java.util.HashMap;
import java.util.Map;

/*해당 클래스가 MVC모델에서 control부분을 담당하는 파일리라는것을 알려주는 어노테이션
 * @Controller : 일반적인 control부분을 담당하는 어노테이션
 * @restController : Restful API 방식을 사용할 경우 사용하느 어노테이션 (클라이언트에 데이터 자체를 전송)*/
@Controller
public class BoardController {

	@Autowired
	private DfService dfService;

	@RequestMapping(value = "/analysis.do", method = RequestMethod.GET)
	public ModelAndView analysis_trading_area(@RequestParam(required = false, defaultValue = "1", value = "pageNum") int pageNum) throws Exception {
		ModelAndView mv = new ModelAndView("board/analysis");
		PageInfo<DfDto> page = new PageInfo<>(dfService.selectEmpList(pageNum), 5);

		mv.addObject("aa", page);

		int arrays[] = {1, 2, 3, 4, 5};

		return mv;
	}

	@ResponseBody
	@RequestMapping(value = "/info.do", method = RequestMethod.POST)
	public PageInfo<DfDto> initBoard(@RequestParam(defaultValue = "0", value = "minRentPrc") String minRentPrc,
									 @RequestParam(defaultValue = "5200", value = "maxRentPrc") String maxRentPrc,
									 @RequestParam(defaultValue = "0", value = "minArea") String minArea,
									 @RequestParam(defaultValue = "1000", value = "maxArea") String maxArea,
									 @RequestParam(defaultValue = "0", value = "includeBase") String includeBase,
									 @RequestParam(required = false, defaultValue = "1", value = "pageNum") int pageNum) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("minRentPrc", minRentPrc);
		map.put("maxRentPrc", maxRentPrc);
		map.put("minArea", minArea);
		map.put("maxArea", maxArea);
		map.put("includeBase", includeBase);

		PageInfo<DfDto> dfList = new PageInfo<>(dfService.findEmpList(map, pageNum), 3);

		int arrays[] = {1, 2, 3, 4, 5};
		return dfList;
	}

	@ResponseBody
	@RequestMapping(value = "/get_marker_info.do", method = RequestMethod.POST)
	public DfDto getMarkerInfo(@RequestParam(value = "idx") int idx) throws Exception {
		DfDto target_df = dfService.findByIndex(idx);

		System.out.println(target_df);
		return target_df;
	}

	@RequestMapping(value = "/info.do", method = RequestMethod.GET)
	public ModelAndView openBoardList(@RequestParam(required = false, defaultValue = "1", value = "pageNum") int pageNum) throws Exception {
		ModelAndView mv = new ModelAndView("board/info");
		PageInfo<DfDto> page = new PageInfo<>(dfService.selectEmpList(pageNum), 5);

		mv.addObject("defaultPage", page);

		int arrays[] = {1, 2, 3, 4, 5};

		return mv;
	}

	@RequestMapping(value = "/recommend.do", method = RequestMethod.GET)
	public ModelAndView openRecommend(@RequestParam(required = false, defaultValue = "1", value = "pageNum") int pageNum) throws Exception {
		ModelAndView mv = new ModelAndView("board/recommend");
		PageInfo<DfDto> page = new PageInfo<>(dfService.selectEmpList(pageNum), 5);

		mv.addObject("aa", page);

		int arrays[] = {1, 2, 3, 4, 5};

		return mv;
	}


	@ResponseBody
	@RequestMapping(value = "/recommend.do", method = RequestMethod.POST)
	public PageInfo<DfDto> estateRecommend(@RequestParam(required = false, value = "radius") String radius,
										   @RequestParam(required = false,value = "lat") String lat,
										   @RequestParam(required = false,value = "lng") String lng) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("radius", radius);
		map.put("lat", lat);
		map.put("lng", lng);

		PageInfo<DfDto> dfList = new PageInfo<>(dfService.findBestEstate(map), 10);

		int arrays[] = {1, 2, 3, 4, 5};
		return dfList;
	}

}