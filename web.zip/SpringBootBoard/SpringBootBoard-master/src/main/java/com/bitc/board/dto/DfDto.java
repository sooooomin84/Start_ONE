package com.bitc.board.dto;

import lombok.Data;

@Data
public class DfDto {
    private int idx;
    private int rankIndex;
    private String tradeTypeName;
    private int rentPrc;
    private int dealOrWarrantPrc;
    private float area2;
    private int floorEstate;
    private int floorBuilding;
    private float latitude;
    private float longitude;
    private int flowPop;
    private int busN;
    private int parkingN;
    private int cafeN;
    private int bicycleN;
    private int subwayN;
    private float subwayD;
    private int schoolN;
    private int storeR;
    private int restN;
    private float score;
    private int n2Prc;
    private float pricePerArea;
    private float costEf;
    private int costEfRank;
    private int scoreRank;
    private float totalRank;
//
}

