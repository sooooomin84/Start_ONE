package com.bitc.board.service;

import java.util.List;
import java.util.Map;

import com.bitc.board.dto.DfDto;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.bitc.board.mapper.DfMapper;

@Service
public class DfServiceImpl implements DfService {
    @Autowired
    private DfMapper dfMapper;

    @Override
    public List<DfDto> selectDfList(DfDto df) throws Exception {
        /* mybatis와 연결되어 있는 BoardMapper를 이용하여 실제 데이터베이스에서 데이터를 조회 */
        return dfMapper.selectDfList(df);
    }

    @Override
    public List<DfDto> openDfList() throws Exception {
        return dfMapper.openDfList();
    }

    @Override
    public Page<DfDto> selectEmpList(int pageNum) throws Exception {
        PageHelper.startPage(pageNum, 5);
        return dfMapper.selectEmpList();
    }

    @Override
    public Page<DfDto> findEmpList(Map map, int pageNum) throws Exception {
        PageHelper.startPage(pageNum, 10);
        return dfMapper.findEmpList(map);
    }

    @Override
    public DfDto findByIndex(int idx) throws Exception {
        return dfMapper.findByIndex(idx);
    }

    public Page<DfDto> findByRank(int pageNum) throws Exception {
        return dfMapper.findByRank(pageNum);
    }
    @Override
    public Page<DfDto> findBestEstate(Map map) throws Exception {
        return dfMapper.findBestEstate(map);
    }
}
