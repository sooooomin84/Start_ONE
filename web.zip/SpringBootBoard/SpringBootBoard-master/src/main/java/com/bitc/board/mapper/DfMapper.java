package com.bitc.board.mapper;

import java.util.List;
import java.util.Map;

import com.github.pagehelper.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.bitc.board.dto.DfDto;


/* mybatis와 연결되어 있다는 것을 의미하는 어노테이션*/
@Mapper
public interface DfMapper {
    List<DfDto> selectDfList(DfDto df) throws Exception;

    List<DfDto> openDfList() throws Exception;

    Page<DfDto> selectEmpList() throws Exception;

    Page<DfDto> findEmpList(Map map) throws Exception;

    DfDto findByIndex(int idx) throws Exception;

    Page<DfDto> findByRank(int pageNum) throws Exception;

    Page<DfDto> findBestEstate(Map map) throws Exception;
}
