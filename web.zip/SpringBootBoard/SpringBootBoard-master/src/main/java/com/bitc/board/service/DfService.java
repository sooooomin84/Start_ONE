package com.bitc.board.service;

import java.util.List;
import java.util.Map;

import com.bitc.board.dto.DfDto;
import com.github.pagehelper.Page;
import org.springframework.web.multipart.MultipartHttpServletRequest;

public interface DfService {
    public List<DfDto> selectDfList(DfDto df) throws Exception;
    List<DfDto> openDfList() throws Exception;

    Page<DfDto> selectEmpList(int pageNum) throws Exception;

    public Page<DfDto> findEmpList(Map map, int pageNum) throws Exception;

    public DfDto findByIndex(int idx) throws Exception;

    public Page<DfDto> findByRank(int pageNum) throws Exception;

    public Page<DfDto> findBestEstate(Map map) throws Exception;
}
